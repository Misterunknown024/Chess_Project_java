@echo off
echo Compiling Chess Game...
if not exist out mkdir out
javac -d out src\chess\*.java
if %errorlevel% neq 0 (
    echo Compilation failed!
    pause
    exit /b 1
)
echo Running Chess Game...
java -cp out chess.ChessGUI
