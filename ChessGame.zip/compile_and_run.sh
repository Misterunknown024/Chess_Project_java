#!/bin/bash
echo "Compiling Chess Game..."
mkdir -p out
javac -d out src/chess/*.java
if [ $? -ne 0 ]; then
    echo "Compilation failed!"
    exit 1
fi
echo "Running Chess Game..."
java -cp out chess.ChessGUI
