package chess;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Swing-based GUI for the Chess Game.
 * Module 05 requirement: paintComponent chessboard, piece selection highlight,
 * move status JLabel, JFrame/JPanel/ActionListener.
 */
public class ChessGUI extends JFrame {

    private Game game;
    private BoardPanel boardPanel;
    private JLabel statusLabel;
    private JLabel whiteInfoLabel;
    private JLabel blackInfoLabel;
    private int selectedRow = -1;
    private int selectedCol = -1;

    public ChessGUI() {
        game = new Game();
        initUI();
    }

    private void initUI() {
        setTitle("Chess Game — OOP Project");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(5, 5));
        getContentPane().setBackground(new Color(40, 40, 40));

        // ── Top info bar ──────────────────────────────────────────────────
        JPanel topPanel = new JPanel(new GridLayout(1, 2));
        topPanel.setBackground(new Color(30, 30, 30));
        topPanel.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));

        blackInfoLabel = makeInfoLabel("♟ Black Player  |  Captured: 0");
        whiteInfoLabel = makeInfoLabel("♙ White Player  |  Captured: 0");
        topPanel.add(blackInfoLabel);
        topPanel.add(whiteInfoLabel);
        add(topPanel, BorderLayout.NORTH);

        // ── Board ─────────────────────────────────────────────────────────
        boardPanel = new BoardPanel();
        boardPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleBoardClick(e.getX(), e.getY());
            }
        });
        add(boardPanel, BorderLayout.CENTER);

        // ── Bottom status bar ─────────────────────────────────────────────
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(new Color(30, 30, 30));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));

        statusLabel = new JLabel("White's turn.", SwingConstants.CENTER);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        statusLabel.setForeground(new Color(230, 230, 230));
        bottomPanel.add(statusLabel, BorderLayout.CENTER);

        JButton newGameBtn = new JButton("New Game");
        newGameBtn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        newGameBtn.setBackground(new Color(60, 120, 60));
        newGameBtn.setForeground(Color.WHITE);
        newGameBtn.setFocusPainted(false);
        newGameBtn.setBorderPainted(false);
        newGameBtn.addActionListener(e -> resetGame());
        bottomPanel.add(newGameBtn, BorderLayout.EAST);

        add(bottomPanel, BorderLayout.SOUTH);

        pack();
        setMinimumSize(new Dimension(560, 620));
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JLabel makeInfoLabel(String text) {
        JLabel lbl = new JLabel(text, SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lbl.setForeground(new Color(200, 200, 200));
        return lbl;
    }

    private void handleBoardClick(int x, int y) {
        if (game.isGameOver()) return;

        int cellSize = boardPanel.getCellSize();
        int col = x / cellSize;
        int row = y / cellSize;

        if (!game.getBoard().inBounds(row, col)) return;

        if (selectedRow == -1) {
            // First click — select a piece
            Piece piece = game.getBoard().getPiece(row, col);
            if (piece != null && piece.getColor().equals(game.getCurrentPlayer().getColor())) {
                selectedRow = row;
                selectedCol = col;
                boardPanel.setSelected(row, col);
                boardPanel.repaint();
            }
        } else {
            // Second click — attempt move
            try {
                game.makeMove(selectedRow, selectedCol, row, col);
                updateInfoLabels();
                statusLabel.setForeground(new Color(100, 220, 100));
            } catch (InvalidMoveException ex) {
                statusLabel.setForeground(new Color(255, 100, 100));
                game = game; // keep state
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Invalid Move", JOptionPane.WARNING_MESSAGE);
            } catch (CheckException ex) {
                statusLabel.setForeground(new Color(255, 80, 80));
                JOptionPane.showMessageDialog(this, ex.getMessage(), "In Check!", JOptionPane.ERROR_MESSAGE);
            } finally {
                selectedRow = -1;
                selectedCol = -1;
                boardPanel.setSelected(-1, -1);
            }

            statusLabel.setText(game.getStatusMessage());
            boardPanel.repaint();

            if (game.isGameOver()) {
                JOptionPane.showMessageDialog(this, game.getStatusMessage(), "Game Over", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void updateInfoLabels() {
        whiteInfoLabel.setText("♙ White Player  |  Captured: " + game.getWhitePlayer().getCapturedPieces());
        blackInfoLabel.setText("♟ Black Player  |  Captured: " + game.getBlackPlayer().getCapturedPieces());
    }

    private void resetGame() {
        game = new Game();
        selectedRow = -1;
        selectedCol = -1;
        boardPanel.setGame(game);
        boardPanel.setSelected(-1, -1);
        statusLabel.setText("White's turn.");
        statusLabel.setForeground(new Color(230, 230, 230));
        updateInfoLabels();
        boardPanel.repaint();
    }

    // ─── Inner class: BoardPanel ──────────────────────────────────────────────

    private class BoardPanel extends JPanel {

        private static final int CELL = 70;
        private Game panelGame;
        private int selRow = -1, selCol = -1;

        // Piece Unicode symbols
        private static final String[][] WHITE_SYMBOLS = {
            {"♖","♘","♗","♕","♔","♗","♘","♖"},
            {"♙","♙","♙","♙","♙","♙","♙","♙"}
        };

        BoardPanel() {
            panelGame = game;
            setPreferredSize(new Dimension(CELL * 8, CELL * 8));
        }

        void setGame(Game g) { panelGame = g; }
        void setSelected(int r, int c) { selRow = r; selCol = c; }
        int getCellSize() { return getWidth() / Board.SIZE; }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();
            int cell = Math.min(w, h) / Board.SIZE;

            // Colors
            Color lightSquare = new Color(240, 217, 181);
            Color darkSquare  = new Color(181, 136,  99);
            Color highlight   = new Color(255, 255,  80, 160);
            Color checkColor  = new Color(255,  50,  50, 160);
            Color legalMove   = new Color(100, 200, 100, 100);

            Board board = panelGame.getBoard();

            // Compute legal destinations for selected piece
            boolean[][] legalDests = new boolean[Board.SIZE][Board.SIZE];
            if (selRow >= 0) {
                Piece sel = board.getPiece(selRow, selCol);
                if (sel != null) {
                    for (int r = 0; r < Board.SIZE; r++)
                        for (int c = 0; c < Board.SIZE; c++) {
                            if (sel.isValidMove(selRow, selCol, r, c, board)) {
                                Board sim = new Board(board);
                                sim.movePiece(selRow, selCol, r, c);
                                if (!sim.isInCheck(sel.getColor()))
                                    legalDests[r][c] = true;
                            }
                        }
                }
            }

            for (int row = 0; row < Board.SIZE; row++) {
                for (int col = 0; col < Board.SIZE; col++) {
                    int x = col * cell;
                    int y = row * cell;

                    // Draw square
                    boolean isLight = (row + col) % 2 == 0;
                    g2.setColor(isLight ? lightSquare : darkSquare);
                    g2.fillRect(x, y, cell, cell);

                    // Selection highlight
                    if (row == selRow && col == selCol) {
                        g2.setColor(highlight);
                        g2.fillRect(x, y, cell, cell);
                    }

                    // Legal move dots
                    if (legalDests[row][col]) {
                        g2.setColor(legalMove);
                        Piece target = board.getPiece(row, col);
                        if (target != null) {
                            // Highlight captures with border
                            g2.setStroke(new BasicStroke(4));
                            g2.drawOval(x + 2, y + 2, cell - 4, cell - 4);
                            g2.setStroke(new BasicStroke(1));
                        } else {
                            int dotSize = cell / 3;
                            g2.fillOval(x + (cell - dotSize) / 2, y + (cell - dotSize) / 2, dotSize, dotSize);
                        }
                    }

                    // Check highlight on King
                    Piece p = board.getPiece(row, col);
                    if (p instanceof King) {
                        String color = p.getColor();
                        if (board.isInCheck(color)) {
                            g2.setColor(checkColor);
                            g2.fillRect(x, y, cell, cell);
                        }
                    }

                    // Draw piece
                    if (p != null) {
                        String sym = getPieceUnicode(p);
                        g2.setFont(new Font("Segoe UI Emoji", Font.PLAIN, (int)(cell * 0.72)));
                        FontMetrics fm = g2.getFontMetrics();
                        int tx = x + (cell - fm.stringWidth(sym)) / 2;
                        int ty = y + (cell + fm.getAscent() - fm.getDescent()) / 2;

                        // Shadow
                        g2.setColor(new Color(0, 0, 0, 60));
                        g2.drawString(sym, tx + 1, ty + 1);
                        // Piece
                        g2.setColor(p.getColor().equals("White") ? Color.WHITE : new Color(20, 20, 20));
                        g2.drawString(sym, tx, ty);
                    }
                }
            }

            // Rank/File labels
            g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
            for (int i = 0; i < Board.SIZE; i++) {
                // Files a-h
                g2.setColor((i % 2 == 0) ? darkSquare : lightSquare);
                g2.drawString(String.valueOf((char)('a' + i)), i * cell + cell - 12, Board.SIZE * cell - 3);
                // Ranks 8-1
                g2.setColor((i % 2 == 0) ? lightSquare : darkSquare);
                g2.drawString(String.valueOf(8 - i), 2, i * cell + 14);
            }
        }

        private String getPieceUnicode(Piece p) {
            boolean white = p.getColor().equals("White");
            if (p instanceof King)   return white ? "♔" : "♚";
            if (p instanceof Queen)  return white ? "♕" : "♛";
            if (p instanceof Rook)   return white ? "♖" : "♜";
            if (p instanceof Bishop) return white ? "♗" : "♝";
            if (p instanceof Knight) return white ? "♘" : "♞";
            if (p instanceof Pawn)   return white ? "♙" : "♟";
            return "?";
        }
    }

    // ─── Main ─────────────────────────────────────────────────────────────────

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}
            new ChessGUI();
        });
    }
}
