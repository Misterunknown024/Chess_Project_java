package chess;

// ─── KING ────────────────────────────────────────────────────────────────────
class King extends Piece {

    public King(String color) { super(color); }

    @Override
    public boolean isValidMove(int fr, int fc, int tr, int tc, Board board) {
        if (isFriendlyOccupied(tr, tc, board)) return false;
        int rowDiff = Math.abs(tr - fr);
        int colDiff = Math.abs(tc - fc);
        return rowDiff <= 1 && colDiff <= 1 && (rowDiff + colDiff > 0);
    }

    @Override
    public String getSymbol() { return "K"; }
}

// ─── QUEEN ───────────────────────────────────────────────────────────────────
class Queen extends Piece {

    public Queen(String color) { super(color); }

    @Override
    public boolean isValidMove(int fr, int fc, int tr, int tc, Board board) {
        if (isFriendlyOccupied(tr, tc, board)) return false;
        boolean straight = (fr == tr || fc == tc);
        boolean diagonal = (Math.abs(tr - fr) == Math.abs(tc - fc));
        if (!straight && !diagonal) return false;
        return isPathClear(fr, fc, tr, tc, board);
    }

    @Override
    public String getSymbol() { return "Q"; }
}

// ─── ROOK ────────────────────────────────────────────────────────────────────
class Rook extends Piece {

    public Rook(String color) { super(color); }

    @Override
    public boolean isValidMove(int fr, int fc, int tr, int tc, Board board) {
        if (isFriendlyOccupied(tr, tc, board)) return false;
        if (fr != tr && fc != tc) return false;
        return isPathClear(fr, fc, tr, tc, board);
    }

    @Override
    public String getSymbol() { return "R"; }
}

// ─── BISHOP ──────────────────────────────────────────────────────────────────
class Bishop extends Piece {

    public Bishop(String color) { super(color); }

    @Override
    public boolean isValidMove(int fr, int fc, int tr, int tc, Board board) {
        if (isFriendlyOccupied(tr, tc, board)) return false;
        if (Math.abs(tr - fr) != Math.abs(tc - fc)) return false;
        return isPathClear(fr, fc, tr, tc, board);
    }

    @Override
    public String getSymbol() { return "B"; }
}

// ─── KNIGHT ──────────────────────────────────────────────────────────────────
class Knight extends Piece {

    public Knight(String color) { super(color); }

    @Override
    public boolean isValidMove(int fr, int fc, int tr, int tc, Board board) {
        if (isFriendlyOccupied(tr, tc, board)) return false;
        int rd = Math.abs(tr - fr);
        int cd = Math.abs(tc - fc);
        return (rd == 2 && cd == 1) || (rd == 1 && cd == 2);
    }

    @Override
    public String getSymbol() { return "N"; }
}

// ─── PAWN ────────────────────────────────────────────────────────────────────
class Pawn extends Piece {

    public Pawn(String color) { super(color); }

    @Override
    public boolean isValidMove(int fr, int fc, int tr, int tc, Board board) {
        int direction = getColor().equals("White") ? -1 : 1; // White moves up (decreasing row)
        int startRow  = getColor().equals("White") ? 6 : 1;

        // One step forward
        if (tc == fc && tr == fr + direction && board.getPiece(tr, tc) == null)
            return true;

        // Two steps from starting row
        if (tc == fc && fr == startRow && tr == fr + 2 * direction
                && board.getPiece(fr + direction, fc) == null
                && board.getPiece(tr, tc) == null)
            return true;

        // Diagonal capture
        if (Math.abs(tc - fc) == 1 && tr == fr + direction) {
            Piece target = board.getPiece(tr, tc);
            return target != null && !target.getColor().equals(getColor());
        }

        return false;
    }

    @Override
    public String getSymbol() { return "P"; }
}
