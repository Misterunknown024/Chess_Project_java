package chess;

/**
 * Represents a chess player.
 * Demonstrates Encapsulation with private fields and getters/setters.
 */
public class Player {

    private final String name;
    private final String color;
    private int capturedPieces;
    private boolean inCheck;

    // Constructor Overloading
    public Player(String name, String color) {
        this.name = name;
        this.color = color;
        this.capturedPieces = 0;
        this.inCheck = false;
    }

    public Player(String color) {
        this(color + " Player", color);
    }

    // Getters and Setters
    public String getName() { return name; }
    public String getColor() { return color; }
    public int getCapturedPieces() { return capturedPieces; }
    public boolean isInCheck() { return inCheck; }

    public void setInCheck(boolean inCheck) { this.inCheck = inCheck; }
    public void incrementCaptured() { capturedPieces++; }

    @Override
    public String toString() {
        return name + " (" + color + ")";
    }
}
