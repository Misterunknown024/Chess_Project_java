package chess;

/**
 * Interface representing any piece that can move on the chessboard.
 */
public interface Movable {
    boolean isValidMove(int fromRow, int fromCol, int toRow, int toCol, Board board);
    String getSymbol();
}
