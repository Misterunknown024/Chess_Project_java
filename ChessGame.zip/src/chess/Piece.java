package chess;

/**
 * Abstract base class for all chess pieces.
 * Demonstrates Abstraction, Encapsulation, and Inheritance.
 */
public abstract class Piece implements Movable {

    // Encapsulation: private fields with getters
    private final String color;   // "White" or "Black"
    private boolean captured;

    // Constructor Overloading
    public Piece(String color) {
        this.color = color;
        this.captured = false;
    }

    public Piece(String color, boolean captured) {
        this.color = color;
        this.captured = captured;
    }

    // Getters
    public String getColor() { return color; }
    public boolean isCaptured() { return captured; }
    public void setCaptured(boolean captured) { this.captured = captured; }

    /**
     * Checks whether the destination is occupied by a friendly piece.
     */
    protected boolean isFriendlyOccupied(int toRow, int toCol, Board board) {
        Piece target = board.getPiece(toRow, toCol);
        return target != null && target.getColor().equals(this.color);
    }

    /**
     * Checks whether the path between two squares (exclusive) is clear.
     * Used by Rook, Bishop, Queen.
     */
    protected boolean isPathClear(int fromRow, int fromCol, int toRow, int toCol, Board board) {
        int rowStep = Integer.signum(toRow - fromRow);
        int colStep = Integer.signum(toCol - fromCol);
        int r = fromRow + rowStep;
        int c = fromCol + colStep;
        while (r != toRow || c != toCol) {
            if (board.getPiece(r, c) != null) return false;
            r += rowStep;
            c += colStep;
        }
        return true;
    }

    // Abstract method — Abstraction
    @Override
    public abstract boolean isValidMove(int fromRow, int fromCol, int toRow, int toCol, Board board);

    @Override
    public abstract String getSymbol();

    @Override
    public String toString() {
        return color.charAt(0) + getSymbol();
    }
}
