package chess;

/**
 * Thrown when an illegal move is attempted.
 */
public class InvalidMoveException extends Exception {
    private final int fromRow, fromCol, toRow, toCol;

    public InvalidMoveException(String message, int fromRow, int fromCol, int toRow, int toCol) {
        super(message);
        this.fromRow = fromRow;
        this.fromCol = fromCol;
        this.toRow = toRow;
        this.toCol = toCol;
    }

    public InvalidMoveException(String message) {
        super(message);
        this.fromRow = -1; this.fromCol = -1; this.toRow = -1; this.toCol = -1;
    }

    @Override
    public String toString() {
        if (fromRow >= 0)
            return "InvalidMoveException: " + getMessage() +
                   " [(" + fromRow + "," + fromCol + ") -> (" + toRow + "," + toCol + ")]";
        return "InvalidMoveException: " + getMessage();
    }
}
