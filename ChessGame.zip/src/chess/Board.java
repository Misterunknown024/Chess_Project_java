package chess;

/**
 * Represents the 8x8 chessboard and manages piece positions.
 */
public class Board {

    private final Piece[][] grid;
    public static final int SIZE = 8;

    public Board() {
        grid = new Piece[SIZE][SIZE];
        initializePieces();
    }

    // Deep-copy constructor (used for check detection simulation)
    public Board(Board other) {
        grid = new Piece[SIZE][SIZE];
        for (int r = 0; r < SIZE; r++)
            for (int c = 0; c < SIZE; c++)
                grid[r][c] = other.grid[r][c]; // Pieces are immutable in moves, safe to share reference
    }

    private void initializePieces() {
        // Black back rank
        grid[0][0] = new Rook("Black");
        grid[0][1] = new Knight("Black");
        grid[0][2] = new Bishop("Black");
        grid[0][3] = new Queen("Black");
        grid[0][4] = new King("Black");
        grid[0][5] = new Bishop("Black");
        grid[0][6] = new Knight("Black");
        grid[0][7] = new Rook("Black");
        for (int c = 0; c < SIZE; c++) grid[1][c] = new Pawn("Black");

        // White back rank
        grid[7][0] = new Rook("White");
        grid[7][1] = new Knight("White");
        grid[7][2] = new Bishop("White");
        grid[7][3] = new Queen("White");
        grid[7][4] = new King("White");
        grid[7][5] = new Bishop("White");
        grid[7][6] = new Knight("White");
        grid[7][7] = new Rook("White");
        for (int c = 0; c < SIZE; c++) grid[6][c] = new Pawn("White");
    }

    public Piece getPiece(int row, int col) {
        if (!inBounds(row, col)) return null;
        return grid[row][col];
    }

    public void setPiece(int row, int col, Piece piece) {
        if (inBounds(row, col)) grid[row][col] = piece;
    }

    public boolean inBounds(int row, int col) {
        return row >= 0 && row < SIZE && col >= 0 && col < SIZE;
    }

    /**
     * Executes a move without validation (used after validation is confirmed).
     */
    public void movePiece(int fromRow, int fromCol, int toRow, int toCol) {
        grid[toRow][toCol] = grid[fromRow][fromCol];
        grid[fromRow][fromCol] = null;
    }

    /**
     * Finds the position of the King of the given color.
     */
    public int[] findKing(String color) {
        for (int r = 0; r < SIZE; r++)
            for (int c = 0; c < SIZE; c++) {
                Piece p = grid[r][c];
                if (p instanceof King && p.getColor().equals(color))
                    return new int[]{r, c};
            }
        return null;
    }

    /**
     * Returns true if the given color's King is under attack.
     */
    public boolean isInCheck(String color) {
        int[] kingPos = findKing(color);
        if (kingPos == null) return false;
        String opponent = color.equals("White") ? "Black" : "White";
        for (int r = 0; r < SIZE; r++)
            for (int c = 0; c < SIZE; c++) {
                Piece p = grid[r][c];
                if (p != null && p.getColor().equals(opponent))
                    if (p.isValidMove(r, c, kingPos[0], kingPos[1], this))
                        return true;
        }
        return false;
    }
}
