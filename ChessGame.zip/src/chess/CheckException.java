package chess;

/**
 * Thrown when a move leaves or puts the player's own King in check.
 */
public class CheckException extends Exception {
    private final String playerColor;

    public CheckException(String playerColor) {
        super(playerColor + "'s King is in check!");
        this.playerColor = playerColor;
    }

    public String getPlayerColor() {
        return playerColor;
    }

    @Override
    public String toString() {
        return "CheckException: " + getMessage();
    }
}
