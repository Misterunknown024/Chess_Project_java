package chess;

/**
 * Core game logic: turn management, move validation, check/checkmate detection.
 * Demonstrates Inheritance use (all piece types), Exception Handling, and game state tracking.
 */
public class Game {

    private final Board board;
    private final Player whitePlayer;
    private final Player blackPlayer;
    private Player currentPlayer;
    private String statusMessage;
    private boolean gameOver;
    private String winner;

    public Game() {
        board = new Board();
        whitePlayer = new Player("White");
        blackPlayer = new Player("Black");
        currentPlayer = whitePlayer;
        statusMessage = "White's turn.";
        gameOver = false;
        winner = null;
    }

    /**
     * Attempts to make a move. Throws checked exceptions on invalid or check-causing moves.
     */
    public void makeMove(int fromRow, int fromCol, int toRow, int toCol)
            throws InvalidMoveException, CheckException {

        if (gameOver) throw new InvalidMoveException("The game is already over.");

        Piece piece = board.getPiece(fromRow, fromCol);

        // Validate source
        if (piece == null)
            throw new InvalidMoveException("No piece at selected square.", fromRow, fromCol, toRow, toCol);
        if (!piece.getColor().equals(currentPlayer.getColor()))
            throw new InvalidMoveException("That is not your piece.", fromRow, fromCol, toRow, toCol);

        // Validate piece movement rules
        if (!piece.isValidMove(fromRow, fromCol, toRow, toCol, board))
            throw new InvalidMoveException("Invalid move for " + piece.getClass().getSimpleName() + ".",
                    fromRow, fromCol, toRow, toCol);

        // Simulate move and check if own king ends up in check
        Board simulated = new Board(board);
        simulated.movePiece(fromRow, fromCol, toRow, toCol);
        if (simulated.isInCheck(currentPlayer.getColor()))
            throw new CheckException(currentPlayer.getColor());

        // Commit the move
        Piece captured = board.getPiece(toRow, toCol);
        if (captured != null) currentPlayer.incrementCaptured();
        board.movePiece(fromRow, fromCol, toRow, toCol);

        // Pawn promotion
        if (piece instanceof Pawn) {
            if ((piece.getColor().equals("White") && toRow == 0) ||
                (piece.getColor().equals("Black") && toRow == 7)) {
                board.setPiece(toRow, toCol, new Queen(piece.getColor()));
            }
        }

        // Switch turn
        Player opponent = (currentPlayer == whitePlayer) ? blackPlayer : whitePlayer;

        // Update check state
        boolean opponentInCheck = board.isInCheck(opponent.getColor());
        opponent.setInCheck(opponentInCheck);
        currentPlayer.setInCheck(false);

        if (opponentInCheck) {
            if (isCheckmate(opponent.getColor())) {
                gameOver = true;
                winner = currentPlayer.getColor();
                statusMessage = currentPlayer.getColor() + " wins by Checkmate!";
            } else {
                statusMessage = opponent.getColor() + " is in CHECK!";
            }
        } else if (isStalemate(opponent.getColor())) {
            gameOver = true;
            statusMessage = "Stalemate! It's a draw.";
        } else {
            statusMessage = opponent.getColor() + "'s turn.";
        }

        currentPlayer = opponent;
    }

    /**
     * Returns true if the given color has no legal moves and is in check.
     */
    private boolean isCheckmate(String color) {
        return !hasAnyLegalMove(color) && board.isInCheck(color);
    }

    /**
     * Returns true if the given color has no legal moves but is NOT in check.
     */
    private boolean isStalemate(String color) {
        return !hasAnyLegalMove(color) && !board.isInCheck(color);
    }

    private boolean hasAnyLegalMove(String color) {
        for (int fr = 0; fr < Board.SIZE; fr++)
            for (int fc = 0; fc < Board.SIZE; fc++) {
                Piece p = board.getPiece(fr, fc);
                if (p == null || !p.getColor().equals(color)) continue;
                for (int tr = 0; tr < Board.SIZE; tr++)
                    for (int tc = 0; tc < Board.SIZE; tc++) {
                        if (!p.isValidMove(fr, fc, tr, tc, board)) continue;
                        Board sim = new Board(board);
                        sim.movePiece(fr, fc, tr, tc);
                        if (!sim.isInCheck(color)) return true;
                    }
            }
        return false;
    }

    // ── Getters ──────────────────────────────────────────────────────────────

    public Board getBoard() { return board; }
    public Player getCurrentPlayer() { return currentPlayer; }
    public Player getWhitePlayer() { return whitePlayer; }
    public Player getBlackPlayer() { return blackPlayer; }
    public String getStatusMessage() { return statusMessage; }
    public boolean isGameOver() { return gameOver; }
    public String getWinner() { return winner; }
}
